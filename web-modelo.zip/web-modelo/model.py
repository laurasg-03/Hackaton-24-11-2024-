import os

# Cargar el contenido del archivo HL7 predeterminado
default_hl7_path = "mensaje_hl7.txt"
if os.path.exists(default_hl7_path):
    with open(default_hl7_path, 'r', encoding='latin-1') as file:
        default_hl7_content = file.read()
else:
    default_hl7_content = "No se pudo encontrar el archivo HL7 predeterminado."

def predict_fibrosis(image_path):
    # Aquí es donde integrarás tu modelo de predicción
    # Ejemplo de cómo podrías cargar un modelo de TensorFlow
    # import tensorflow as tf
    # model = tf.keras.models.load_model('ruta/a/tu/modelo.h5')
    
    # Usar el archivo HL7 predeterminado si no hay modelo
    result = default_hl7_content
    probabilidad = "probabilidad de FPI"
    # Generar el informe HL7
    report_filename = os.path.basename(image_path).replace('.', '_') + '_report.hl7'
    report_path = os.path.join('results', report_filename)
    
    # Crear la carpeta de resultados si no existe
    os.makedirs(os.path.dirname(report_path), exist_ok=True)
    
    generate_hl7_report(report_path, result)
    
    return result, report_path, probabilidad

def generate_hl7_report(report_path, result):
    with open(report_path, 'w', encoding='latin-1') as file:
        file.write(result)

def hl7_to_text(file_path):
    try:
        # Leer el contenido del archivo HL7
        with open(file_path, 'r', encoding='latin-1') as file:
            hl7_message = file.read()
    except Exception as e:
        return f"Error al leer el archivo: {e}"
    
    # Separa el mensaje HL7 en segmentos utilizando el delimitador '\n'
    segments = hl7_message.strip().split('\n')
    
    # Convertirlo en un texto comprensible
    text_output = []

    # Recorrer cada segmento
    for segment in segments:
        fields = segment.split('|')  # Separa el segmento en campos usando '|'
        
        # Segmento PID (Información del paciente)
        if fields[0] == 'PID':
            patient_info = fields[5].split('^')  # Nombre del paciente
            patient_name = ' '.join(patient_info)  # Unir nombre completo
            text_output.append(f"Datos del paciente: \n Nombre: {patient_name} \n Fecha de nacimiento: {fields[7][0:4]}/{fields[7][4:6]}/{fields[7][6:8]} \n Sexo: {fields[8]} \n Dirección: {fields[11]} \n Teléfono: {fields[13]}")
        
        # Segmentos OBX (Observaciones, FVC, porcentaje de fibrosis, etc.)
        elif fields[0] == 'OBX':
            observation = fields[3]  # Tipo de observación
            value = fields[5]  # Valor de la observación
            units = fields[6]  # Unidades de medida
            if units == 'N':  # Si las unidades no son relevantes, las omitimos
                units = ''
            # Manejo de observación específica para segmentación
            if "Segmentación CT" in observation:
                text_output.append(f"Segmentación CT:\n{value}")
            else:
                text_output.append(f"{observation}: {value} {units}")
        
        # Segmento DICOM (Información de la imagen)
        elif fields[0] == 'OBX' and 'DICOM' in fields[2]:
            dicom_url = fields[5]  # URL de la imagen
            text_output.append(f"Imagen DICOM: {dicom_url}")
    
    # Si hay algo en el resultado, lo retornamos
    if text_output:
        return "\n".join(text_output)
    else:
        return "No se encontraron datos en el mensaje HL7."
