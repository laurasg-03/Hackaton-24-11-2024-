from flask import Flask, render_template, request, redirect, url_for, send_file
from werkzeug.utils import secure_filename
import os
from model import predict_fibrosis, hl7_to_text

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['RESULT_FOLDER'] = 'results/'

# Crear las carpetas de subida y resultados si no existen
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
os.makedirs(app.config['RESULT_FOLDER'], exist_ok=True)

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file:
            filename = secure_filename(file.filename)
            filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(filepath)
            result, report_path, probabilidad = predict_fibrosis(filepath)
            report_filename = os.path.basename(report_path)  # Obtener solo el nombre del archivo
            return render_template('index.html', result=probabilidad, report_filename=report_filename)
    return render_template('index.html', result=None, report_filename=None)

@app.route('/download/<filename>')
def download_file(filename):
    file_path = os.path.join(app.config['RESULT_FOLDER'], filename)
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)
    else:
        return "El archivo no existe", 404

@app.route('/convert_hl7/<filename>')
def convert_hl7(filename):
    file_path = os.path.join(app.config['RESULT_FOLDER'], filename)
    if os.path.exists(file_path):
        text_result = hl7_to_text(file_path)
        return render_template('hl7_result.html', text_result=text_result)
    else:
        return "El archivo no existe", 404

if __name__ == '__main__':
    app.run(debug=True)